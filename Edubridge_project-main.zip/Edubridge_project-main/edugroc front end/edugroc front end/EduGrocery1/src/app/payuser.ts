export class Payuser {
    
    cardNumber!:string;
    cardName!:string;
    cardExpiry!:string;
    upiNumber!:string;
     address!:string;
     contact_num!:string;
    name!:String;

}
