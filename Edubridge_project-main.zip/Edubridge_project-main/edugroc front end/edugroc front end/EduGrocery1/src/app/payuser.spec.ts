import { Payuser } from './payuser';

describe('Payuser', () => {
  it('should create an instance', () => {
    expect(new Payuser()).toBeTruthy();
  });
});
